/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MiniAudio/MiniAudio/src/View/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[22];
    char stringdata0[317];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_PlayButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 25), // "on_AddMuiscButton_clicked"
QT_MOC_LITERAL(4, 60, 22), // "on_PauseButton_clicked"
QT_MOC_LITERAL(5, 83, 32), // "on_horizontalSlider_valueChanged"
QT_MOC_LITERAL(6, 116, 5), // "value"
QT_MOC_LITERAL(7, 122, 7), // "cmdTone"
QT_MOC_LITERAL(8, 130, 12), // "cmdFrequency"
QT_MOC_LITERAL(9, 143, 7), // "getTone"
QT_MOC_LITERAL(10, 151, 9), // "tonevalue"
QT_MOC_LITERAL(11, 161, 12), // "getFrequency"
QT_MOC_LITERAL(12, 174, 8), // "freValue"
QT_MOC_LITERAL(13, 183, 10), // "plotAllWav"
QT_MOC_LITERAL(14, 194, 5), // "char*"
QT_MOC_LITERAL(15, 200, 8), // "fileName"
QT_MOC_LITERAL(16, 209, 21), // "on_stopButton_clicked"
QT_MOC_LITERAL(17, 231, 21), // "on_NextButton_clicked"
QT_MOC_LITERAL(18, 253, 21), // "on_LastButton_clicked"
QT_MOC_LITERAL(19, 275, 27), // "on_listWidget_doubleClicked"
QT_MOC_LITERAL(20, 303, 5), // "index"
QT_MOC_LITERAL(21, 309, 7) // "onTimer"

    },
    "MainWindow\0on_PlayButton_clicked\0\0"
    "on_AddMuiscButton_clicked\0"
    "on_PauseButton_clicked\0"
    "on_horizontalSlider_valueChanged\0value\0"
    "cmdTone\0cmdFrequency\0getTone\0tonevalue\0"
    "getFrequency\0freValue\0plotAllWav\0char*\0"
    "fileName\0on_stopButton_clicked\0"
    "on_NextButton_clicked\0on_LastButton_clicked\0"
    "on_listWidget_doubleClicked\0index\0"
    "onTimer"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   84,    2, 0x08 /* Private */,
       3,    0,   85,    2, 0x08 /* Private */,
       4,    0,   86,    2, 0x08 /* Private */,
       5,    1,   87,    2, 0x08 /* Private */,
       7,    0,   90,    2, 0x08 /* Private */,
       8,    0,   91,    2, 0x08 /* Private */,
       9,    1,   92,    2, 0x08 /* Private */,
      11,    1,   95,    2, 0x08 /* Private */,
      13,    1,   98,    2, 0x08 /* Private */,
      16,    0,  101,    2, 0x08 /* Private */,
      17,    0,  102,    2, 0x08 /* Private */,
      18,    0,  103,    2, 0x08 /* Private */,
      19,    1,  104,    2, 0x08 /* Private */,
      21,    0,  107,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Double,   12,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   20,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_PlayButton_clicked(); break;
        case 1: _t->on_AddMuiscButton_clicked(); break;
        case 2: _t->on_PauseButton_clicked(); break;
        case 3: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->cmdTone(); break;
        case 5: _t->cmdFrequency(); break;
        case 6: _t->getTone((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->getFrequency((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 8: _t->plotAllWav((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 9: _t->on_stopButton_clicked(); break;
        case 10: _t->on_NextButton_clicked(); break;
        case 11: _t->on_LastButton_clicked(); break;
        case 12: _t->on_listWidget_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 13: _t->onTimer(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    if (!strcmp(_clname, "Observer"))
        return static_cast< Observer*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
