/********************************************************************************
** Form generated from reading UI file 'frequency.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FREQUENCY_H
#define UI_FREQUENCY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Frequency
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *NameFrequency;
    QDoubleSpinBox *doubleSpinBox;

    void setupUi(QDialog *Frequency)
    {
        if (Frequency->objectName().isEmpty())
            Frequency->setObjectName(QStringLiteral("Frequency"));
        Frequency->resize(400, 300);
        buttonBox = new QDialogButtonBox(Frequency);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(30, 240, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        NameFrequency = new QLabel(Frequency);
        NameFrequency->setObjectName(QStringLiteral("NameFrequency"));
        NameFrequency->setGeometry(QRect(70, 100, 72, 15));
        doubleSpinBox = new QDoubleSpinBox(Frequency);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setGeometry(QRect(70, 140, 161, 41));

        retranslateUi(Frequency);
        QObject::connect(buttonBox, SIGNAL(accepted()), Frequency, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Frequency, SLOT(reject()));

        QMetaObject::connectSlotsByName(Frequency);
    } // setupUi

    void retranslateUi(QDialog *Frequency)
    {
        Frequency->setWindowTitle(QApplication::translate("Frequency", "Dialog", 0));
        NameFrequency->setText(QApplication::translate("Frequency", "\351\242\221\347\216\207\345\200\274", 0));
    } // retranslateUi

};

namespace Ui {
    class Frequency: public Ui_Frequency {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FREQUENCY_H
