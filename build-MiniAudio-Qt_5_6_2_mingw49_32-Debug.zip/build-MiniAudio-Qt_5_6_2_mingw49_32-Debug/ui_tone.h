/********************************************************************************
** Form generated from reading UI file 'tone.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TONE_H
#define UI_TONE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSlider>

QT_BEGIN_NAMESPACE

class Ui_Tone
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *NameTone;
    QSlider *horizontalSlider;
    QLabel *ToneValue;

    void setupUi(QDialog *Tone)
    {
        if (Tone->objectName().isEmpty())
            Tone->setObjectName(QStringLiteral("Tone"));
        Tone->resize(400, 300);
        buttonBox = new QDialogButtonBox(Tone);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(160, 240, 221, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        NameTone = new QLabel(Tone);
        NameTone->setObjectName(QStringLiteral("NameTone"));
        NameTone->setGeometry(QRect(80, 100, 91, 31));
        NameTone->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByKeyboard);
        horizontalSlider = new QSlider(Tone);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(20, 160, 371, 22));
        horizontalSlider->setOrientation(Qt::Horizontal);
        ToneValue = new QLabel(Tone);
        ToneValue->setObjectName(QStringLiteral("ToneValue"));
        ToneValue->setGeometry(QRect(160, 110, 72, 15));

        retranslateUi(Tone);
        QObject::connect(buttonBox, SIGNAL(accepted()), Tone, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), Tone, SLOT(reject()));

        QMetaObject::connectSlotsByName(Tone);
    } // setupUi

    void retranslateUi(QDialog *Tone)
    {
        Tone->setWindowTitle(QApplication::translate("Tone", "Dialog", 0));
        NameTone->setText(QApplication::translate("Tone", "\351\237\263\350\260\203\345\200\274\357\274\232", 0));
        ToneValue->setText(QApplication::translate("Tone", "A6", 0));
    } // retranslateUi

};

namespace Ui {
    class Tone: public Ui_Tone {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TONE_H
