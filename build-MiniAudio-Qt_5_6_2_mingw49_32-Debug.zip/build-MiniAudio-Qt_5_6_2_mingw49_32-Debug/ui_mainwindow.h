/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include "src/View/Plot/curveplot.h"
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionSaveAs;
    QAction *actionTone;
    QAction *actionFrequency;
    QAction *actionAbout;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QPushButton *NextButton;
    CurvePlot *ploter;
    QSlider *horizontalSlider;
    QListWidget *listWidget;
    QPushButton *PlayButton;
    QPushButton *PauseButton;
    QPushButton *LastButton;
    QPushButton *AddMuiscButton;
    QPushButton *stopButton;
    QLabel *MusicName;
    CurvePlot *ploterAll;
    QLabel *PositionLable;
    QMenuBar *menuBar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_3;
    QMenu *menu_4;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1293, 586);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        actionSaveAs = new QAction(MainWindow);
        actionSaveAs->setObjectName(QStringLiteral("actionSaveAs"));
        actionTone = new QAction(MainWindow);
        actionTone->setObjectName(QStringLiteral("actionTone"));
        actionFrequency = new QAction(MainWindow);
        actionFrequency->setObjectName(QStringLiteral("actionFrequency"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        NextButton = new QPushButton(centralWidget);
        NextButton->setObjectName(QStringLiteral("NextButton"));

        gridLayout->addWidget(NextButton, 5, 6, 1, 1);

        ploter = new CurvePlot(centralWidget);
        ploter->setObjectName(QStringLiteral("ploter"));
        ploter->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(ploter, 0, 2, 2, 6);

        horizontalSlider = new QSlider(centralWidget);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSlider, 4, 2, 1, 5);

        listWidget = new QListWidget(centralWidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));

        gridLayout->addWidget(listWidget, 0, 0, 5, 2);

        PlayButton = new QPushButton(centralWidget);
        PlayButton->setObjectName(QStringLiteral("PlayButton"));

        gridLayout->addWidget(PlayButton, 5, 3, 1, 1);

        PauseButton = new QPushButton(centralWidget);
        PauseButton->setObjectName(QStringLiteral("PauseButton"));

        gridLayout->addWidget(PauseButton, 5, 4, 1, 1);

        LastButton = new QPushButton(centralWidget);
        LastButton->setObjectName(QStringLiteral("LastButton"));

        gridLayout->addWidget(LastButton, 5, 2, 1, 1);

        AddMuiscButton = new QPushButton(centralWidget);
        AddMuiscButton->setObjectName(QStringLiteral("AddMuiscButton"));

        gridLayout->addWidget(AddMuiscButton, 5, 0, 1, 1);

        stopButton = new QPushButton(centralWidget);
        stopButton->setObjectName(QStringLiteral("stopButton"));

        gridLayout->addWidget(stopButton, 5, 5, 1, 1);

        MusicName = new QLabel(centralWidget);
        MusicName->setObjectName(QStringLiteral("MusicName"));

        gridLayout->addWidget(MusicName, 3, 2, 1, 5);

        ploterAll = new CurvePlot(centralWidget);
        ploterAll->setObjectName(QStringLiteral("ploterAll"));

        gridLayout->addWidget(ploterAll, 2, 2, 1, 6);

        PositionLable = new QLabel(centralWidget);
        PositionLable->setObjectName(QStringLiteral("PositionLable"));

        gridLayout->addWidget(PositionLable, 4, 7, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1293, 26));
        menu = new QMenu(menuBar);
        menu->setObjectName(QStringLiteral("menu"));
        menu_2 = new QMenu(menuBar);
        menu_2->setObjectName(QStringLiteral("menu_2"));
        menu_3 = new QMenu(menuBar);
        menu_3->setObjectName(QStringLiteral("menu_3"));
        menu_4 = new QMenu(menuBar);
        menu_4->setObjectName(QStringLiteral("menu_4"));
        MainWindow->setMenuBar(menuBar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);
        MainWindow->insertToolBarBreak(toolBar);
#ifndef QT_NO_SHORTCUT
#endif // QT_NO_SHORTCUT

        menuBar->addAction(menu->menuAction());
        menuBar->addAction(menu_2->menuAction());
        menuBar->addAction(menu_3->menuAction());
        menuBar->addAction(menu_4->menuAction());
        menu->addAction(actionNew);
        menu->addAction(actionOpen);
        menu->addAction(actionSave);
        menu->addAction(actionSaveAs);
        menu_3->addAction(actionTone);
        menu_3->addAction(actionFrequency);
        menu_4->addAction(actionAbout);
        toolBar->addAction(actionTone);
        toolBar->addSeparator();
        toolBar->addAction(actionFrequency);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionNew->setText(QApplication::translate("MainWindow", "\346\226\260\345\273\272", 0));
        actionNew->setShortcut(QApplication::translate("MainWindow", "Ctrl+N", 0));
        actionOpen->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200", 0));
        actionSave->setText(QApplication::translate("MainWindow", "\344\277\235\345\255\230", 0));
        actionSaveAs->setText(QApplication::translate("MainWindow", "\345\217\246\345\255\230\344\270\272", 0));
        actionTone->setText(QApplication::translate("MainWindow", "\351\237\263\350\260\203", 0));
        actionFrequency->setText(QApplication::translate("MainWindow", "\351\242\221\347\216\207", 0));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0));
        NextButton->setText(QApplication::translate("MainWindow", "\344\270\213\344\270\200\351\246\226", 0));
        PlayButton->setText(QApplication::translate("MainWindow", "\346\222\255\346\224\276", 0));
        PauseButton->setText(QApplication::translate("MainWindow", "\346\232\202\345\201\234", 0));
        LastButton->setText(QApplication::translate("MainWindow", "\344\270\212\344\270\200\351\246\226", 0));
        AddMuiscButton->setText(QApplication::translate("MainWindow", "\346\267\273\345\212\240\351\237\263\344\271\220", 0));
        stopButton->setText(QApplication::translate("MainWindow", "\345\201\234\346\255\242", 0));
        MusicName->setText(QString());
        PositionLable->setText(QApplication::translate("MainWindow", "00:00", 0));
        menu->setTitle(QApplication::translate("MainWindow", "\346\226\207\344\273\266", 0));
        menu_2->setTitle(QApplication::translate("MainWindow", "\347\274\226\350\276\221", 0));
        menu_3->setTitle(QApplication::translate("MainWindow", "\346\225\210\346\236\234", 0));
        menu_4->setTitle(QApplication::translate("MainWindow", "\345\270\256\345\212\251", 0));
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
